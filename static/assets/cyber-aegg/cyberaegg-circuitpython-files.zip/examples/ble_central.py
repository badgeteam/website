"""Connect from one badge to another.

Copy to CIRCUITPY/code.py on one badge, and `ble_uart.py` on a second one.
No libraries needed.

This badge scans, picks the other badge out of what it hears, connects, holds
the connection for a moment, and lets go. The other badge prints `connected`
and `disconnected` on its own console, so both sides show the same thing.

    found CyberAegg at <Address ea:0f:88:a5:c2:c9>, -45 dBm
    connected in 0.2 s
    still connected: True
    disconnected

## What a connection gives you, and what it does not

The link comes up, and `Connection.connected` follows it. What you cannot do
yet is talk over it. Reading and writing the characteristics of the other badge
needs the GATT client, and `Connection.discover_remote_services()` still
returns nothing. So a connection is worth making today to prove two badges
reach each other, or to hold a link while something else runs, but not yet to
exchange data.

To exchange data between badges now, use `ble_telemetry.py` and `ble_scan.py`
instead. Those put the payload in the advertisement, which needs no connection
at all and reaches every badge in range at once.
"""
import time
import _bleio

NAME = "CyberAegg"
SCAN_SECONDS = 8
HOLD_SECONDS = 3

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")


def name_of(data):
    """Pull the name out of an advertising packet, if it carries one."""
    index = 0
    while index < len(data):
        length = data[index]
        if length == 0 or index + length >= len(data) + 1:
            return None
        ad_type = data[index + 1]
        if ad_type in (0x08, 0x09):          # shortened or complete name
            try:
                return data[index + 2:index + 1 + length].decode("utf-8")
            except UnicodeError:
                return None
        index += 1 + length
    return None


def find_other_badge():
    """Return the address of another badge, or None."""
    found = None
    for entry in adapter.start_scan(timeout=SCAN_SECONDS, interval=0.1,
                                    window=0.1, minimum_rssi=-100):
        if found is None and entry.connectable and \
                name_of(entry.advertisement_bytes) == NAME:
            print("found %s at %s, %d dBm" % (NAME, entry.address, entry.rssi))
            found = entry.address
    # The scan runs to its timeout even after a match, so stop it rather than
    # leave the controller scanning into the next thing this program does.
    adapter.stop_scan()
    return found


print("scanning for another badge")
print("this badge is", adapter.address)

target = find_other_badge()
if target is None:
    print("no other badge in range")
    print("copy ble_uart.py to a second badge and reset it")
else:
    start = time.monotonic()
    connection = adapter.connect(target, timeout=10)
    print("connected in %.1f s" % (time.monotonic() - start))
    time.sleep(HOLD_SECONDS)
    print("still connected:", connection.connected)
    connection.disconnect()
    time.sleep(1)
    print("disconnected")

print("done")
