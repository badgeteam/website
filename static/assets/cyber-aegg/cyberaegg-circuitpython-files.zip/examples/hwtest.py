"""Peripheral self-test: LED, buzzer, charger, battery, I2C, buttons/joystick.

Copy to CIRCUITPY/code.py and watch the serial console. Press each button and
joystick direction. Ctrl-C stops the input loop.
"""
import time
import board
import digitalio

print("\n=== CyberÆgg hardware test ===")

# RGB LED (active-low: value False = on)
for name in ("LED_RED", "LED_GREEN", "LED_BLUE"):
    led = digitalio.DigitalInOut(getattr(board, name))
    led.switch_to_output(value=True)
    led.value = False
    time.sleep(0.4)
    led.value = True
    led.deinit()

# Buzzer
try:
    import pwmio
    buz = pwmio.PWMOut(board.BUZZER, frequency=1000, duty_cycle=0, variable_frequency=True)
    for f in (700, 1100, 1600):
        buz.frequency = f
        buz.duty_cycle = 32768
        time.sleep(0.15)
    buz.duty_cycle = 0
    buz.deinit()
except Exception as e:
    print("buzzer:", e)

# Charger (low = charging)
chg = digitalio.DigitalInOut(board.CHARGE)
chg.switch_to_input(pull=digitalio.Pull.UP)
print("charger:", "charging" if not chg.value else "not charging")
chg.deinit()

# Battery: P0_31 reads 1/3 of Vbat. Enable the divider by pulling P0_07 low.
import analogio
import microcontroller
rd = digitalio.DigitalInOut(microcontroller.pin.P0_07)
rd.switch_to_output(value=False)
time.sleep(0.01)
adc = analogio.AnalogIn(board.VBAT)
print("battery: %.2f V" % (adc.value / 65535 * adc.reference_voltage * 3.0))
adc.deinit()
rd.value = True
rd.deinit()

# I2C (QWIIC). Note: this connector has 3V3/GND swapped vs standard QWIIC.
i2c = board.I2C()
while not i2c.try_lock():
    pass
print("I2C:", [hex(a) for a in i2c.scan()])
i2c.unlock()

# Buttons + joystick (active-low with pull-ups)
import keypad
names = ["BTN_CANCEL", "BTN_EXECUTE", "JOY_UP", "JOY_DOWN", "JOY_LEFT", "JOY_RIGHT", "JOY_FIRE"]
keys = keypad.Keys([getattr(board, n) for n in names], value_when_pressed=False, pull=True)
print("press each button / joystick direction (Ctrl-C to stop):")
while True:
    ev = keys.events.get()
    if ev:
        print(" ", names[ev.key_number], "pressed" if ev.pressed else "released")
    time.sleep(0.01)
