"""Serve an NFC tag. Tapping a phone to the badge opens the URL.

Copy this file to CIRCUITPY/code.py. The tag runs in the background, so the rest
of your program keeps working after start() returns.
"""
import nfctag

nfctag.start("https://codeberg.org/rarenerd/cyberaegg-circuitpython")
print("NFC tag running, tap a phone to the badge")
