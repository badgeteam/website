"""Connect to another device and list what it offers.

Copy to CIRCUITPY/code.py on one badge, and `ble_uart.py` on a second one.
No libraries needed.

To look at something other than a badge, put its name or the start of its
address in TARGET below. A watch, a fitness band or a sensor lists its own
table the same way. That is worth doing: everything here was tested against a
second badge, so against the same Bluetooth stack on both sides.

This badge scans, connects to the other badge, and reads its attribute table:
every service, and every characteristic inside it. That is the GATT client
side, and it is what lets a badge use a device rather than only find it.

    found CyberAegg at <Address ea:0f:88:a5:c2:c9>, -45 dBm
    connected in 0.2 s
    3 services in 0.6 s

      service UUID(0x1800)
         char UUID(0x2a00)  read
         char UUID(0x2a01)  read
      service UUID(0x1801)
         char UUID(0x2a05)  indicate
            desc UUID(0x2902)  <- subscribe here
      service UUID('6e400001-b5a3-f393-e0a9-e50e24dcca9e')
         char UUID('6e400002-b5a3-f393-e0a9-e50e24dcca9e')  write write-no-response
         char UUID('6e400003-b5a3-f393-e0a9-e50e24dcca9e')  notify
            desc UUID(0x2902)  <- subscribe here

The first two services are the ones every device carries. The third is the
Nordic UART Service that `ble_uart.py` adds, so the properties here are a
direct check: its RX characteristic accepts writes, and its TX notifies.

## What you can do with the result

Read a characteristic with `characteristic.value`, write it by assigning to the
same attribute, and subscribe to one that notifies with
`characteristic.set_cccd(notify=True)`. A characteristic that notifies carries
a descriptor with UUID 0x2902, which the listing marks.

Pairing is not supported, so a device that asks for it before answering will
not list anything here.
"""
import time
import _bleio

# What to look for. A name, or the start of an address like "ea:0f". Set it to
# another device to explore that instead.
TARGET = "CyberAegg"
SCAN_SECONDS = 8

# The properties of a characteristic, in the order _bleio numbers them.
PROPERTY_NAMES = (
    (_bleio.Characteristic.BROADCAST, "broadcast"),
    (_bleio.Characteristic.INDICATE, "indicate"),
    (_bleio.Characteristic.NOTIFY, "notify"),
    (_bleio.Characteristic.READ, "read"),
    (_bleio.Characteristic.WRITE, "write"),
    (_bleio.Characteristic.WRITE_NO_RESPONSE, "write-no-response"),
)

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")


def name_of(data):
    """Pull the name out of an advertising packet, if it carries one."""
    index = 0
    while index < len(data):
        length = data[index]
        if length == 0 or index + length >= len(data) + 1:
            return None
        if data[index + 1] in (0x08, 0x09):     # shortened or complete name
            try:
                return data[index + 2:index + 1 + length].decode("utf-8")
            except UnicodeError:
                return None
        index += 1 + length
    return None


def properties_of(characteristic):
    flags = characteristic.properties
    names = [name for bit, name in PROPERTY_NAMES if flags & bit]
    return " ".join(names) if names else "none"


def matches(entry):
    name = name_of(entry.advertisement_bytes)
    if name is not None and TARGET.lower() in name.lower():
        return True
    return TARGET.lower() in str(entry.address).lower()


def find_target():
    """Return the address of the first device that matches TARGET.

    Do not ask for `entry.connectable` here. Many devices put their name in the
    scan response rather than in the advertisement, and a scan response arrives
    as its own entry with `connectable` false. Requiring both at once then
    never matches: the entry with the name is not the entry that says it
    accepts connections.
    """
    found = None
    for entry in adapter.start_scan(timeout=SCAN_SECONDS, interval=0.1,
                                    window=0.1, minimum_rssi=-100):
        if found is None and matches(entry):
            print("found %s at %s, %d dBm" %
                  (name_of(entry.advertisement_bytes) or "device",
                   entry.address, entry.rssi))
            found = entry.address
    # The scan runs to its timeout even after a match, so stop it rather than
    # leave the controller scanning into the connection.
    adapter.stop_scan()
    return found


print("scanning for", TARGET)
print("this badge is", adapter.address)

target = find_target()
if target is None:
    print("nothing matching %r in range" % TARGET)
    print("copy ble_uart.py to a second badge and reset it,")
    print("or set TARGET to another device")
else:
    start = time.monotonic()
    connection = adapter.connect(target, timeout=10)
    print("connected in %.1f s" % (time.monotonic() - start))

    start = time.monotonic()
    services = connection.discover_remote_services()
    print("%d services in %.1f s\n" % (len(services), time.monotonic() - start))

    for service in services:
        print("  service", service.uuid)
        for characteristic in service.characteristics:
            print("     char %s  %s" % (characteristic.uuid,
                                        properties_of(characteristic)))
            for descriptor in characteristic.descriptors:
                note = "  <- subscribe here" if characteristic.descriptors and \
                    "2902" in str(descriptor.uuid) else ""
                print("        desc %s%s" % (descriptor.uuid, note))

    connection.disconnect()
    print("\ndisconnected")

print("done")
