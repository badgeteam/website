"""Connect to another device and list what it offers.

Copy to CIRCUITPY/code.py on one badge, and `ble_uart.py` on a second one.
No libraries needed.

This badge scans, connects to the other badge, and reads its attribute table:
every service, and every characteristic inside it. That is the GATT client
side, which lets a badge use a device rather than only find it.

    found CyberAegg at <Address ea:0f:88:a5:c2:c9>, -45 dBm
    connected in 0.2 s
    3 services in 0.6 s

      service UUID(0x1800)
         char UUID(0x2a00)  read
         char UUID(0x2a01)  read
      service UUID(0x1801)
         char UUID(0x2a05)  indicate
      service UUID('6e400001-b5a3-f393-e0a9-e50e24dcca9e')
         char UUID('6e400002-b5a3-f393-e0a9-e50e24dcca9e')  write write-no-response
         char UUID('6e400003-b5a3-f393-e0a9-e50e24dcca9e')  notify

The first two services are the ones every device carries. The third is the
Nordic UART Service which `ble_uart.py` adds, so the properties here are a
direct check: its RX characteristic accepts writes, and its TX notifies.

Point this at anything, not only at a badge. A fitness band or a sensor will
list its own services the same way.

## What you can do with the result, and what you cannot yet

Discovery works. Reading and writing the characteristics you find does not:
`Characteristic.value` on a remote characteristic is not implemented in this
firmware. So this tells you what a device offers, which is the step every
client has to take first, but the next step is not there yet.
"""
import time
import _bleio

NAME = "CyberAegg"
SCAN_SECONDS = 8

# The properties of a characteristic, in the order _bleio numbers them.
PROPERTY_NAMES = (
    (_bleio.Characteristic.BROADCAST, "broadcast"),
    (_bleio.Characteristic.INDICATE, "indicate"),
    (_bleio.Characteristic.NOTIFY, "notify"),
    (_bleio.Characteristic.READ, "read"),
    (_bleio.Characteristic.WRITE, "write"),
    (_bleio.Characteristic.WRITE_NO_RESPONSE, "write-no-response"),
)

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")


def name_of(data):
    """Pull the name out of an advertising packet, if it carries one."""
    index = 0
    while index < len(data):
        length = data[index]
        if length == 0 or index + length >= len(data) + 1:
            return None
        if data[index + 1] in (0x08, 0x09):     # shortened or complete name
            try:
                return data[index + 2:index + 1 + length].decode("utf-8")
            except UnicodeError:
                return None
        index += 1 + length
    return None


def properties_of(characteristic):
    flags = characteristic.properties
    names = [name for bit, name in PROPERTY_NAMES if flags & bit]
    return " ".join(names) if names else "none"


def find_other_badge():
    found = None
    for entry in adapter.start_scan(timeout=SCAN_SECONDS, interval=0.1,
                                    window=0.1, minimum_rssi=-100):
        if found is None and entry.connectable and \
                name_of(entry.advertisement_bytes) == NAME:
            print("found %s at %s, %d dBm" % (NAME, entry.address, entry.rssi))
            found = entry.address
    # The scan runs to its timeout even after a match, so stop it rather than
    # leave the controller scanning into the connection.
    adapter.stop_scan()
    return found


print("scanning for another badge")
print("this badge is", adapter.address)

target = find_other_badge()
if target is None:
    print("no other badge in range")
    print("copy ble_uart.py to a second badge and reset it")
else:
    start = time.monotonic()
    connection = adapter.connect(target, timeout=10)
    print("connected in %.1f s" % (time.monotonic() - start))

    start = time.monotonic()
    services = connection.discover_remote_services()
    print("%d services in %.1f s\n" % (len(services), time.monotonic() - start))

    for service in services:
        print("  service", service.uuid)
        for characteristic in service.characteristics:
            print("     char %s  %s" % (characteristic.uuid,
                                        properties_of(characteristic)))

    connection.disconnect()
    print("\ndisconnected")

print("done")
