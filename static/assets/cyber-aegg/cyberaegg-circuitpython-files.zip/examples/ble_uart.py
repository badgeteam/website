"""Nordic UART Service over Bluetooth, printed to the serial console.

Copy to CIRCUITPY/code.py. No libraries needed.

The badge advertises as "CyberAegg". Connect with any BLE terminal app, such as
nRF Connect or Adafruit Bluefruit Connect, and anything you send appears on the
badge's serial console. Whatever the badge sends back is delivered as a
notification.

This is the smallest useful GATT example: it does nothing slow, so it is also
the right thing to run when working out whether a connection problem is in
Bluetooth or in whatever else the program was doing.

Do not drive the e-paper display from the same program. displayio's background
work and Bluetooth contend for the same time, and a connection does not
survive a panel refresh. See docs/BLUETOOTH.md.
"""
import time
import _bleio

NUS_SERVICE = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_RX = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   # client writes here
NUS_TX = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   # badge notifies here

NAME = "CyberAegg"

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

service = _bleio.Service(_bleio.UUID(NUS_SERVICE))
rx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_RX),
    properties=_bleio.Characteristic.WRITE | _bleio.Characteristic.WRITE_NO_RESPONSE,
    max_length=180,
)
tx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_TX),
    properties=_bleio.Characteristic.NOTIFY,
    max_length=180,
)
incoming = _bleio.CharacteristicBuffer(rx, timeout=0.1, buffer_size=256)

# Legacy advertising has 31 bytes, so flags plus the name is all that fits.
# Clients find the UART service after connecting.
FLAGS = bytes((2, 0x01, 0x06))
name = NAME.encode("utf-8")
advertisement = FLAGS + bytes((len(name) + 1, 0x09)) + name


def start_advertising():
    adapter.start_advertising(
        advertisement,
        scan_response=None,
        connectable=True,
        anonymous=False,
        timeout=0,
        interval=0.1,
        tx_power=0,
        directed_to=None,
    )


start_advertising()
print("advertising as", NAME)
print("address:", adapter.address)

was_connected = False
try:
    while True:
        connected = adapter.connected
        if connected != was_connected:
            print("connected" if connected else "disconnected")
            was_connected = connected
            if not connected and not adapter.advertising:
                start_advertising()

        if incoming.in_waiting:
            data = incoming.read(incoming.in_waiting)
            if data:
                try:
                    text = data.decode("utf-8")
                except UnicodeError:
                    text = repr(data)
                print("received:", text.strip())
                try:
                    tx.value = b"echo: " + data
                except Exception:
                    # No client has subscribed to notifications.
                    pass

        time.sleep(0.05)
except KeyboardInterrupt:
    adapter.stop_advertising()
    print("stopped")
