"""A Python prompt on the badge, reached over Bluetooth.

Copy to CIRCUITPY/code.py. No libraries needed.

The badge advertises as "CyberAegg" with a Nordic UART Service. Connect with
any BLE terminal application, such as nRF Connect or Adafruit Bluefruit
Connect, and open the UART view. Send a line of Python. The badge runs it and
sends the result back.

    >>> 2 + 2
    4
    >>> import board, digitalio
    >>> led = digitalio.DigitalInOut(board.LED_RED)
    >>> led.switch_to_output(value=False)
    >>> led.value = True

Names stay for the whole session, so you can build up state line by line. Send
`help` for the short command list.

This is not the CircuitPython REPL. The REPL of the supervisor cannot run over
Bluetooth on this firmware, because it starts before the MicroPython heap
exists. See `docs/BLUETOOTH.md`. This example runs inside `code.py` instead,
where the heap is available, and it gives the same thing for most purposes.

Two limits come from that:

- Ctrl-C does not stop a running line. A loop which does not end keeps the
  badge busy until you reset it.
  A line which merely takes a long time is safe. MicroPython runs the
  background work between bytecodes, so the connection stays up while your
  code runs. Measured: `sum(range(1000000))` took 25 seconds and answered
  over the same connection, and `time.sleep(45)` also kept it.
- `sys.stdout` cannot be replaced on this build, so this example puts its own
  `print` into the namespace of your code. A print from inside a library still
  goes to the USB console.

If connections keep timing out, disconnect any Bluetooth headset from the host
first. A headset takes nearly all of the radio time, and connection attempts
then fail while scanning still works. See `docs/BLUETOOTH.md`.
"""
import time
import _bleio

NAME = "CyberAegg"

NUS_SERVICE = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_RX = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   # client writes here
NUS_TX = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   # badge notifies here

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

service = _bleio.Service(_bleio.UUID(NUS_SERVICE))
rx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_RX),
    properties=_bleio.Characteristic.WRITE | _bleio.Characteristic.WRITE_NO_RESPONSE,
    max_length=180,
)
tx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_TX),
    properties=_bleio.Characteristic.NOTIFY,
    max_length=180,
)
incoming = _bleio.CharacteristicBuffer(rx, timeout=0.1, buffer_size=256)

# Legacy advertising has 31 bytes, so flags plus the name is all that fits.
FLAGS = bytes((2, 0x01, 0x06))
name_bytes = NAME.encode("utf-8")
advertisement = FLAGS + bytes((len(name_bytes) + 1, 0x09)) + name_bytes

# One notification holds ATT_MTU minus three bytes, and the MTU here is the
# minimum 23. Longer replies go in several notifications, with a pause between
# them so the client can keep up.
CHUNK = 20
CHUNK_PAUSE = 0.05

# A reply longer than this is cut. A long traceback would otherwise take
# seconds to send, twenty bytes at a time.
MAX_REPLY = 400

HELP = """\
Send a line of Python. Names stay for the session.
  help    this text
  vars    names you have defined
  clear   forget them
"""


def send(text):
    """Send text to the client in pieces it can receive."""
    data = text.encode("utf-8")
    if len(data) > MAX_REPLY:
        data = data[:MAX_REPLY] + b"...\n"
    for start in range(0, len(data), CHUNK):
        try:
            tx.value = data[start:start + CHUNK]
        except Exception:
            # No client is subscribed, so drop the rest.
            return
        time.sleep(CHUNK_PAUSE)


# The namespace your lines run in. It survives from one line to the next, which
# is what makes this a session rather than a series of unrelated commands.
session = {}
_collected = []


def _print(*args, **kwargs):
    """Stand in for print(), because sys.stdout cannot be replaced here."""
    sep = kwargs.get("sep", " ")
    end = kwargs.get("end", "\n")
    _collected.append(sep.join(str(a) for a in args) + end)


def reset_session():
    session.clear()
    session["print"] = _print
    session["__name__"] = "__main__"


reset_session()


def run(line):
    """Run one line and return what to send back."""
    del _collected[:]

    if line == "help":
        return HELP
    if line == "vars":
        names = sorted(n for n in session if not n.startswith("__") and n != "print")
        return (", ".join(names) if names else "(none)") + "\n"
    if line == "clear":
        reset_session()
        return "cleared\n"

    # An expression gives a value worth showing. A statement does not compile
    # as one, so fall back to exec and show whatever it printed.
    try:
        result = eval(line, session)
        if result is not None:
            _collected.append(repr(result) + "\n")
    except SyntaxError:
        try:
            exec(line, session)
        except Exception as error:
            _collected.append("%s: %s\n" % (type(error).__name__, error))
    except Exception as error:
        _collected.append("%s: %s\n" % (type(error).__name__, error))

    return "".join(_collected) or "ok\n"


def start_advertising():
    adapter.start_advertising(
        advertisement,
        scan_response=None,
        connectable=True,
        anonymous=False,
        timeout=0,
        interval=0.1,
        tx_power=0,
        directed_to=None,
    )


start_advertising()
print("advertising as", NAME)
print("address:", adapter.address)
print("connect and send Python over the UART service")

pending = ""
was_connected = False
try:
    while True:
        connected = adapter.connected
        if connected != was_connected:
            was_connected = connected
            print("connected" if connected else "disconnected")
            if connected:
                pending = ""
            elif not adapter.advertising:
                start_advertising()

        if incoming.in_waiting:
            data = incoming.read(incoming.in_waiting)
            if data:
                try:
                    pending += data.decode("utf-8")
                except UnicodeError:
                    pending = ""
                # A terminal application may send a line with either ending, or
                # none at all until the user presses send.
                while "\n" in pending or "\r" in pending:
                    for ending in ("\r\n", "\n", "\r"):
                        if ending in pending:
                            line, pending = pending.split(ending, 1)
                            break
                    line = line.strip()
                    if line:
                        print(">>>", line)
                        reply = run(line)
                        print(reply, end="")
                        send(reply)

        time.sleep(0.02)
except KeyboardInterrupt:
    adapter.stop_advertising()
    print("stopped")
