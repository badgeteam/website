"""Talk to another device over its Nordic UART Service, as the client.

Copy to CIRCUITPY/code.py on one badge, and `ble_uart.py` on a second one.
No libraries needed.

This is the mirror of `ble_uart.py`. That one waits to be talked to. This one
does the talking: it finds the other badge, connects, subscribes, sends a line,
and prints whatever comes back.

    found CyberAegg at <Address ea:0f:88:a5:c2:c9>, -53 dBm
    connected, ATT MTU 244
    sent 22 bytes
    received 28 bytes: b'echo: hello from the client\n'

Everything a protocol needs is here: connect, find the characteristics by UUID,
write to one, and receive notifications from another. A driver for some other
device is the same shape with different UUIDs and different bytes.

## Notifications

Subscribing has two halves, and both are needed.

`characteristic.set_cccd(notify=True)` tells the other side to start sending.
A `CharacteristicBuffer` on the same characteristic is what catches what
arrives. Without the buffer the notifications are received and dropped, because
nothing is observing that characteristic.

The buffer holds `buffer_size` bytes. A notification bigger than the room left
is lost rather than truncated, so size it for the largest reply you expect.

## What the MTU changes

One notification carries the ATT MTU less three bytes. The MTU is negotiated
when this example connects, and both badges ask for the largest their radio
and buffers allow, so it lands at 244 rather than the minimum 20. A reply of
200 bytes then arrives in one piece instead of ten.

`connection.max_packet_length` is that number. Read it rather than assuming,
because the other side has the last word: the MTU in use is the smaller of the
two offers, and a device that does not negotiate stays at 20.

## Not supported

Pairing. A device that wants pairing before it answers stays closed to the
badge, so this reaches devices that are open, not ones expecting a PIN.
"""
import time
import _bleio

# What to look for. A name, or the start of an address like "ea:0f".
TARGET = "CyberAegg"
SCAN_SECONDS = 8

NUS_RX = "6e400002"      # the other side reads what we write here
NUS_TX = "6e400003"      # the other side notifies us here

MESSAGE = b"hello from the client\n"

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")


def name_of(data):
    """Pull the name out of an advertising packet, if it carries one."""
    index = 0
    while index < len(data):
        length = data[index]
        if length == 0 or index + length >= len(data) + 1:
            return None
        if data[index + 1] in (0x08, 0x09):     # shortened or complete name
            try:
                return data[index + 2:index + 1 + length].decode("utf-8")
            except UnicodeError:
                return None
        index += 1 + length
    return None


def find_target():
    """Return the address of the first device that matches TARGET.

    Do not ask for `entry.connectable` here. Many devices put their name in the
    scan response, and that arrives as its own entry with `connectable` false,
    so the entry with the name is not the entry that says it takes connections.
    """
    found = None
    for entry in adapter.start_scan(timeout=SCAN_SECONDS, interval=0.1,
                                   window=0.1, minimum_rssi=-100):
        if found is None:
            name = name_of(entry.advertisement_bytes)
            if (name is not None and TARGET.lower() in name.lower()) or \
                    TARGET.lower() in str(entry.address).lower():
                print("found %s at %s, %d dBm" %
                      (name or "device", entry.address, entry.rssi))
                found = entry.address
    adapter.stop_scan()
    return found


def characteristics_by_uuid(services, wanted):
    """Map each wanted UUID fragment to the characteristic that carries it."""
    found = {}
    for service in services:
        for characteristic in service.characteristics:
            text = str(characteristic.uuid).lower()
            for fragment in wanted:
                if fragment in text:
                    found[fragment] = characteristic
    return found


print("looking for", TARGET)
target = find_target()
if target is None:
    print("nothing matching %r in range" % TARGET)
    print("copy ble_uart.py to a second badge and reset it")
else:
    connection = adapter.connect(target, timeout=10)
    services = connection.discover_remote_services()
    print("connected, ATT MTU", connection.max_packet_length)

    found = characteristics_by_uuid(services, (NUS_RX, NUS_TX))
    rx = found.get(NUS_RX)
    tx = found.get(NUS_TX)

    if rx is None or tx is None:
        print("the other side has no Nordic UART Service")
    else:
        # The buffer has to exist before the other side starts sending, or the
        # first notifications arrive with nothing observing them.
        inbox = _bleio.CharacteristicBuffer(tx, timeout=0.1, buffer_size=512)
        tx.set_cccd(notify=True)

        rx.value = MESSAGE
        print("sent %d bytes" % len(MESSAGE))

        # Wait a moment for a reply. A device with nothing to say is not a
        # failure, so this does not treat silence as an error.
        deadline = time.monotonic() + 5
        received = b""
        while time.monotonic() < deadline:
            if inbox.in_waiting:
                received += inbox.read(inbox.in_waiting)
                deadline = time.monotonic() + 0.5     # wait for the rest
            time.sleep(0.02)

        if received:
            print("received %d bytes: %r" % (len(received), received))
        else:
            print("no reply within 5 s")

    connection.disconnect()
    print("disconnected")

print("done")
