"""Find the other badges, and read what they broadcast.

Copy to CIRCUITPY/code.py. No libraries needed.

The badge scans, lists what it hears, and decodes the beacon of any other badge
that runs `ble_telemetry.py`. So two badges see each other with no connection
between them.

Run `ble_telemetry.py` on one badge and this on another. This one prints the
battery voltage and the buttons of the other one, and keeps its own beacon on
at the same time, so the two can watch each other.

Scanning is the observer role. The badge listens, and that is all. It cannot
connect to what it finds, because that is the central role, which this firmware
does not have. See `docs/BLUETOOTH.md`.
"""
import time
import struct
import board
import digitalio
import analogio
import microcontroller
import _bleio

NAME = "CyberAegg"
COMPANY_ID = 0xFFFF          # Reserved by the Bluetooth SIG for testing.
FORMAT_VERSION = 1

SCAN_SECONDS = 5
BUTTON_NAMES = ("cancel", "execute", "up", "down", "left", "right", "fire")

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

# The battery divider is enabled by pulling P0.07 low. Keep it off in between.
battery_enable = digitalio.DigitalInOut(microcontroller.pin.P0_07)
battery_enable.switch_to_output(value=True)


def battery_millivolts():
    battery_enable.value = False
    time.sleep(0.01)
    adc = analogio.AnalogIn(board.VBAT)
    volts = adc.value / 65535 * adc.reference_voltage * 3.0
    adc.deinit()
    battery_enable.value = True
    return min(int(volts * 1000), 0xFFFF)


FLAGS = bytes((2, 0x01, 0x06))
name_bytes = NAME.encode("utf-8")
NAME_FIELD = bytes((len(name_bytes) + 1, 0x09)) + name_bytes


def own_advertisement():
    """The same layout ble_telemetry.py uses, so other badges can read us too."""
    payload = struct.pack("<BHIBB", FORMAT_VERSION, battery_millivolts(),
                          int(time.monotonic()), 0, 0)
    manufacturer = struct.pack("<H", COMPANY_ID) + payload
    field = bytes((len(manufacturer) + 1, 0xFF)) + manufacturer
    return FLAGS + NAME_FIELD + field


def advertising_fields(data):
    """Walk the length-type-value structures of an advertising packet."""
    index = 0
    while index < len(data):
        length = data[index]
        if length == 0 or index + length >= len(data) + 1:
            return
        yield data[index + 1], data[index + 2:index + 1 + length]
        index += 1 + length


def describe(data):
    """Return the name and the decoded badge beacon, if either is present."""
    name = None
    beacon = None
    for ad_type, value in advertising_fields(data):
        if ad_type in (0x08, 0x09):          # shortened or complete name
            try:
                name = value.decode("utf-8")
            except UnicodeError:
                name = None
        elif ad_type == 0xFF and len(value) >= 11:
            company = struct.unpack("<H", value[0:2])[0]
            if company == COMPANY_ID and value[2] == FORMAT_VERSION:
                millivolts, uptime, buttons, count = struct.unpack("<HIBB", value[3:11])
                beacon = (millivolts, uptime, buttons, count)
    return name, beacon


def button_list(bits):
    pressed = [BUTTON_NAMES[i] for i in range(len(BUTTON_NAMES)) if bits & (1 << i)]
    return " ".join(pressed) if pressed else "none"


adapter.start_advertising(own_advertisement(), scan_response=None,
                          connectable=False, anonymous=False, timeout=0,
                          interval=0.5, tx_power=0, directed_to=None)
print("scanning, and beaconing as", NAME)
print("address:", adapter.address)

try:
    while True:
        # Keep the strongest report per address, so a device that advertises
        # often is listed once.
        best = {}
        for entry in adapter.start_scan(timeout=SCAN_SECONDS, interval=0.1,
                                        window=0.1, minimum_rssi=-100):
            address = str(entry.address)
            if address not in best or entry.rssi > best[address][0]:
                name, beacon = describe(entry.advertisement_bytes)
                previous = best.get(address)
                # A later report may be a scan response holding only the name,
                # so keep whatever each one added.
                if previous:
                    name = name or previous[1]
                    beacon = beacon or previous[2]
                best[address] = (entry.rssi, name, beacon)

        print("\n%d devices" % len(best))
        for address, (rssi, name, beacon) in sorted(best.items(),
                                                    key=lambda item: -item[1][0]):
            line = "  %s  %4d dBm  %s" % (address, rssi, name or "")
            if beacon:
                millivolts, uptime, buttons, count = beacon
                line += "  [badge %.2f V, up %d s, buttons %s]" % (
                    millivolts / 1000, uptime, button_list(buttons))
            print(line)

        time.sleep(1)
except KeyboardInterrupt:
    adapter.stop_scan()
    adapter.stop_advertising()
    print("stopped")
