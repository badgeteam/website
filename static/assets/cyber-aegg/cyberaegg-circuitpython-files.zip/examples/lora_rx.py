"""LoRa receive. Prints each packet with signal stats as it arrives.

Copy cyberaegg_lora.py and the sx126x driver files to CIRCUITPY/lib, then copy
this to CIRCUITPY/code.py. Run lora_tx.py on a second badge to send, or just
leave it listening to pick up live MeshCore traffic on the badge's default
channel.
"""
import cyberaegg_lora

radio = cyberaegg_lora.LoRa()
sx = radio.radio
print("listening on 869.618 MHz, SF8, BW 62.5, sync 0x1424 (Ctrl-C to stop)")

count = 0
while True:
    data, err = radio.receive(timeout_ms=15000)
    if data:
        count += 1
        print("packet %d: %d bytes, RSSI %.0f dBm, SNR %.1f dB" %
              (count, len(data), sx.getRSSI(), sx.getSNR()))
        print("   ", data)
    else:
        print("nothing in 15 s, still listening (%d heard)" % count)
