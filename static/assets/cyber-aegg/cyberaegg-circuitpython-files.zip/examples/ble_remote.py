"""Control the badge from a phone, and watch the buttons from a phone.

Copy to CIRCUITPY/code.py. No libraries needed.

The badge advertises as "CyberAegg" with a Nordic UART Service, so any BLE
terminal app can talk to it. In nRF Connect or Adafruit Bluefruit Connect,
connect and open the UART view.

Send one of these words:

    red green blue yellow cyan magenta white off
    beep
    help

Press a button or move the joystick and the badge sends the name back, so both
directions are visible in the same app.

The LED and the buzzer answer immediately. That matters: the e-paper display
takes tens of seconds to refresh and a Bluetooth connection does not survive
that, so this example leaves the panel alone.

A reply longer than one notification goes in pieces of twenty bytes, which is
the most the minimum ATT MTU of 23 allows. Measured over one connection: six
replies of up to eight notifications each arrived complete.

If connections keep timing out, disconnect any Bluetooth headset from the host
first. A headset takes nearly all of the radio time, and connection attempts
then fail while scanning still works. See `docs/BLUETOOTH.md`.
"""
import time
import board
import digitalio
import pwmio
import keypad
import _bleio

NAME = "CyberAegg"

NUS_SERVICE = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_RX = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   # phone writes here
NUS_TX = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   # badge notifies here

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

# The LEDs are active low, so False lights them.
leds = {}
for name in ("LED_RED", "LED_GREEN", "LED_BLUE"):
    led = digitalio.DigitalInOut(getattr(board, name))
    led.switch_to_output(value=True)
    leds[name] = led

COLORS = {
    "off": (False, False, False),
    "red": (True, False, False),
    "green": (False, True, False),
    "blue": (False, False, True),
    "yellow": (True, True, False),
    "cyan": (False, True, True),
    "magenta": (True, False, True),
    "white": (True, True, True),
}


def set_color(name):
    red, green, blue = COLORS[name]
    leds["LED_RED"].value = not red
    leds["LED_GREEN"].value = not green
    leds["LED_BLUE"].value = not blue


def beep():
    buzzer = pwmio.PWMOut(board.BUZZER, frequency=1200, duty_cycle=0,
                          variable_frequency=True)
    for frequency in (900, 1300, 1700):
        buzzer.frequency = frequency
        buzzer.duty_cycle = 32768
        time.sleep(0.08)
    buzzer.duty_cycle = 0
    buzzer.deinit()


BUTTONS = ("BTN_CANCEL", "BTN_EXECUTE", "JOY_UP", "JOY_DOWN",
           "JOY_LEFT", "JOY_RIGHT", "JOY_FIRE")
keys = keypad.Keys([getattr(board, name) for name in BUTTONS],
                   value_when_pressed=False, pull=True)

service = _bleio.Service(_bleio.UUID(NUS_SERVICE))
rx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_RX),
    properties=_bleio.Characteristic.WRITE | _bleio.Characteristic.WRITE_NO_RESPONSE,
    max_length=64,
)
tx = _bleio.Characteristic.add_to_service(
    service, _bleio.UUID(NUS_TX),
    properties=_bleio.Characteristic.NOTIFY,
    max_length=64,
)
incoming = _bleio.CharacteristicBuffer(rx, timeout=0.1, buffer_size=128)

# Legacy advertising has 31 bytes, so flags and the name are all that fit.
FLAGS = bytes((2, 0x01, 0x06))
name_bytes = NAME.encode("utf-8")
advertisement = FLAGS + bytes((len(name_bytes) + 1, 0x09)) + name_bytes

HELP = "colors: " + " ".join(sorted(COLORS)) + "\nalso: beep\n"


# One notification holds ATT_MTU minus three bytes, and the MTU here is the
# minimum 23. Anything longer goes in pieces, with a short pause so the client
# keeps up.
NOTIFY_CHUNK = 20
CHUNK_PAUSE = 0.02


def notify(text):
    """Send text to the phone in pieces it can receive, if one is listening."""
    data = text.encode("utf-8")
    for start in range(0, len(data), NOTIFY_CHUNK):
        try:
            tx.value = data[start:start + NOTIFY_CHUNK]
        except Exception:
            # No client has subscribed to notifications.
            return
        time.sleep(CHUNK_PAUSE)


def start_advertising():
    adapter.start_advertising(
        advertisement,
        scan_response=None,
        connectable=True,
        anonymous=False,
        timeout=0,
        interval=0.1,
        tx_power=0,
        directed_to=None,
    )


def handle(command):
    if command in COLORS:
        set_color(command)
        return command + "\n"
    if command == "beep":
        beep()
        return "beep\n"
    if command == "help":
        return HELP
    return "unknown: " + command + "\n"


set_color("off")
start_advertising()
print("advertising as", NAME)
print("address:", adapter.address)
print(HELP, end="")

was_connected = False
try:
    while True:
        connected = adapter.connected
        if connected != was_connected:
            was_connected = connected
            print("connected" if connected else "disconnected")
            if connected:
                set_color("green")
            else:
                set_color("off")
                if not adapter.advertising:
                    start_advertising()

        if incoming.in_waiting:
            data = incoming.read(incoming.in_waiting)
            if data:
                try:
                    text = data.decode("utf-8").strip().lower()
                except UnicodeError:
                    text = ""
                for command in text.split():
                    print("command:", command)
                    notify(handle(command))

        event = keys.events.get()
        if event and event.pressed:
            name = BUTTONS[event.key_number]
            print("pressed:", name)
            notify(name + "\n")

        time.sleep(0.02)
except KeyboardInterrupt:
    adapter.stop_advertising()
    set_color("off")
    print("stopped")
