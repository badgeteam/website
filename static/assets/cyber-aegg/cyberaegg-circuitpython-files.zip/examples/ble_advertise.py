"""Advertise over Bluetooth Low Energy.

Copy to CIRCUITPY/code.py. Then scan with a phone, or on Linux with:

    bluetoothctl --timeout 20 scan le

The badge shows up under its factory address from FICR.DEVICEADDR, which is
the same address the original Rust firmware advertises with.

Only the peripheral role is built into the firmware, so the badge advertises
and can be connected to, but cannot scan for or connect to other devices.
Advertising is legacy, so the payload below has to fit in 31 bytes.
"""
import time
import _bleio

NAME = "CyberAegg"

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

print("address:", adapter.address)

# An advertising payload is a series of length-prefixed fields, each starting
# with a one byte type. See the Bluetooth Core Specification supplement, Part A.
FLAGS = bytes((2, 0x01, 0x06))              # LE General Discoverable, no BR/EDR
name = NAME.encode("utf-8")
COMPLETE_NAME = bytes((len(name) + 1, 0x09)) + name

advertisement = FLAGS + COMPLETE_NAME
if len(advertisement) > 31:
    raise ValueError("advertisement too long for legacy advertising")

adapter.start_advertising(
    advertisement,
    scan_response=None,
    connectable=True,
    anonymous=False,
    timeout=0,          # keep going until stopped
    interval=0.1,       # seconds between advertising events
    tx_power=0,
    directed_to=None,
)

print("advertising as", NAME)

try:
    while True:
        # advertising drops to False by itself once a central connects.
        if not adapter.advertising:
            print("connected, advertising stopped")
            while adapter.connected:
                time.sleep(0.5)
            print("disconnected, advertising again")
            adapter.start_advertising(
                advertisement,
                scan_response=None,
                connectable=True,
                anonymous=False,
                timeout=0,
                interval=0.1,
                tx_power=0,
                directed_to=None,
            )
        time.sleep(0.5)
except KeyboardInterrupt:
    adapter.stop_advertising()
    print("stopped")
