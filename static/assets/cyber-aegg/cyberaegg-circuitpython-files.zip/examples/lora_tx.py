"""LoRa transmit test. Sends a counter every 5 seconds.

Copy cyberaegg_lora.py and the sx126x driver files to CIRCUITPY/lib, then copy
this to CIRCUITPY/code.py. Run lora_rx.py on a second radio to receive.
"""
import time
import cyberaegg_lora

radio = cyberaegg_lora.LoRa()
count = 0
while True:
    message = "hello %d" % count
    length, err = radio.send(message)
    print("sent %r (%d bytes), err %d" % (message, length, err))
    count += 1
    time.sleep(5)
