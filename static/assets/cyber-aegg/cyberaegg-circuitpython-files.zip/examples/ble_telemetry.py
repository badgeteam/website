"""Send the state of the badge to any phone which scans, without a connection.

Copy to CIRCUITPY/code.py. No libraries needed.

The badge puts its battery voltage, its buttons and its uptime into the
advertising packet, and refreshes that packet every two seconds. A scanner
reads it without connecting. Open nRF Connect, scan, and look at the raw data
of "CyberAegg".

This is the most reliable thing Bluetooth does on this badge. Advertising never
fails, while a connection has to be set up and can drop. Nothing here holds the
single connection slot of the controller, so hundreds of badges can report at
once and any number of phones can read them.

The packet is not connectable. To reach the badge over a connection, use
`ble_uart.py` or `ble_repl.py` instead.

## The layout

Legacy advertising has 31 bytes. The flags and the name take 14, so 17 are
left. Manufacturer specific data uses two of those for its own header and two
for a company identifier, which leaves 13 bytes:

    offset  size  meaning
    0       1     format version, 1
    1       2     battery millivolts, unsigned, little endian
    3       4     uptime in seconds, unsigned, little endian
    7       1     buttons, one bit each, 1 means pressed
    8       1     counter, increases by one each refresh, wraps at 256

The button bits, from bit 0: cancel, execute, up, down, left, right, fire.

The company identifier is 0xFFFF, which the Bluetooth SIG keeps for testing.
Use a registered identifier if these badges ever ship as a product.

To read it in Python on a laptop, with `bleak`:

    import asyncio, struct
    from bleak import BleakScanner

    def show(device, adv):
        raw = adv.manufacturer_data.get(0xFFFF)
        if raw and raw[0] == 1:
            mv, uptime, buttons, count = struct.unpack("<HIBB", raw[1:9])
            print(f"{mv / 1000:.2f} V  up {uptime} s  buttons {buttons:07b}")

    async def main():
        async with BleakScanner(show):
            await asyncio.sleep(30)

    asyncio.run(main())
"""
import time
import struct
import board
import digitalio
import analogio
import microcontroller
import _bleio

NAME = "CyberAegg"
COMPANY_ID = 0xFFFF     # Reserved by the Bluetooth SIG for testing.
FORMAT_VERSION = 1
REFRESH_SECONDS = 2.0

adapter = _bleio.adapter
if adapter is None:
    raise RuntimeError("Bluetooth controller did not start")

# Buttons are active low with pull-ups, so False means pressed. The order here
# sets the bit order in the packet.
BUTTONS = ("BTN_CANCEL", "BTN_EXECUTE", "JOY_UP", "JOY_DOWN",
           "JOY_LEFT", "JOY_RIGHT", "JOY_FIRE")
button_pins = []
for name in BUTTONS:
    pin = digitalio.DigitalInOut(getattr(board, name))
    pin.switch_to_input(pull=digitalio.Pull.UP)
    button_pins.append(pin)

# The battery sits behind a divider which P0.07 enables by going low. Keep the
# divider off between readings so it does not drain the battery.
battery_enable = digitalio.DigitalInOut(microcontroller.pin.P0_07)
battery_enable.switch_to_output(value=True)


def battery_millivolts():
    battery_enable.value = False
    time.sleep(0.01)
    adc = analogio.AnalogIn(board.VBAT)
    volts = adc.value / 65535 * adc.reference_voltage * 3.0
    adc.deinit()
    battery_enable.value = True
    return min(int(volts * 1000), 0xFFFF)


def button_bits():
    bits = 0
    for index, pin in enumerate(button_pins):
        if not pin.value:
            bits |= 1 << index
    return bits


FLAGS = bytes((2, 0x01, 0x06))
name_bytes = NAME.encode("utf-8")
NAME_FIELD = bytes((len(name_bytes) + 1, 0x09)) + name_bytes


def advertisement(count):
    payload = struct.pack(
        "<BHIBB",
        FORMAT_VERSION,
        battery_millivolts(),
        int(time.monotonic()),
        button_bits(),
        count,
    )
    manufacturer = struct.pack("<H", COMPANY_ID) + payload
    field = bytes((len(manufacturer) + 1, 0xFF)) + manufacturer
    packet = FLAGS + NAME_FIELD + field
    if len(packet) > 31:
        raise ValueError("advertisement is %d bytes, the limit is 31" % len(packet))
    return packet


def start(packet):
    adapter.start_advertising(
        packet,
        scan_response=None,
        # A beacon does not accept connections, so the single connection slot
        # of the controller stays free.
        connectable=False,
        anonymous=False,
        timeout=0,
        interval=0.5,
        tx_power=0,
        directed_to=None,
    )


count = 0
packet = advertisement(count)
print("beacon as", NAME)
print("address:", adapter.address)
print("packet:", len(packet), "of 31 bytes")

start(packet)
try:
    while True:
        time.sleep(REFRESH_SECONDS)
        count = (count + 1) & 0xFF
        packet = advertisement(count)
        # The packet only changes when advertising restarts.
        adapter.stop_advertising()
        start(packet)
        if count % 15 == 0:
            millivolts = struct.unpack("<H", packet[-8:-6])[0]
            # CircuitPython has no %b, so build the bit string by hand.
            bits = "".join("1" if packet[-2] & (1 << i) else "0"
                           for i in range(len(BUTTONS)))
            print("battery %.2f V, buttons %s" % (millivolts / 1000, bits))
except KeyboardInterrupt:
    adapter.stop_advertising()
    print("stopped")
