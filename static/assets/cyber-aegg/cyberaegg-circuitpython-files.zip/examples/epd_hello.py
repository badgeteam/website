"""E-paper hello: white field, black border, black + red squares.

Copy cyberaegg_epd.py to CIRCUITPY/lib/ and this file to CIRCUITPY/code.py.
"""
import displayio
import cyberaegg_epd
from cyberaegg_epd import WIDTH, HEIGHT, WHITE, BLACK, RED

display = cyberaegg_epd.get_display()

palette = displayio.Palette(3)
palette[0] = WHITE
palette[1] = BLACK
palette[2] = RED
bmp = displayio.Bitmap(WIDTH, HEIGHT, 3)
bmp.fill(0)

for i in range(WIDTH):
    for t in range(3):
        bmp[i, t] = 1
        bmp[i, HEIGHT - 1 - t] = 1
        bmp[t, i] = 1
        bmp[WIDTH - 1 - t, i] = 1
for y in range(12, 52):
    for x in range(12, 52):
        bmp[x, y] = 1
for y in range(HEIGHT - 52, HEIGHT - 12):
    for x in range(WIDTH - 52, WIDTH - 12):
        bmp[x, y] = 2

group = displayio.Group()
group.append(displayio.TileGrid(bmp, pixel_shader=palette))
display.root_group = group

# One full refresh, with the white background baked into this same frame.
cyberaegg_epd.refresh(display)
print("done")
