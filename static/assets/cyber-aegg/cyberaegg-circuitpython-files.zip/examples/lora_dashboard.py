"""LoRa dashboard on the e-ink: listen for MeshCore packets and show live stats.

Copy cyberaegg_lora.py, the sx126x driver files and cyberaegg_epd.py to
CIRCUITPY/lib, add the adafruit_display_text library there too, then copy this to
CIRCUITPY/code.py. The panel redraws every few packets. A full refresh is slow,
so this is a snapshot dashboard, not animation.
"""
import time
import displayio
import terminalio
import cyberaegg_epd
import cyberaegg_lora
from adafruit_display_text import label
from cyberaegg_epd import WIDTH, HEIGHT, WHITE, BLACK, RED

display = cyberaegg_epd.get_display()
radio = cyberaegg_lora.LoRa()
sx = radio.radio

group = displayio.Group()

# White background. Labels draw on a transparent background, so without this the
# panel stays black and the black text is invisible.
bg = displayio.Bitmap(WIDTH, HEIGHT, 1)
bg_pal = displayio.Palette(1)
bg_pal[0] = WHITE
group.append(displayio.TileGrid(bg, pixel_shader=bg_pal))


def add_label(y, color):
    text = label.Label(terminalio.FONT, text="", color=color, scale=2)
    text.x = 6
    text.y = y
    group.append(text)
    return text


title = add_label(14, RED)
title.text = "LoRa RX"
l_pkts = add_label(44, BLACK)
l_last = add_label(70, BLACK)
l_rssi = add_label(96, BLACK)
l_snr = add_label(122, BLACK)

bar_bmp = displayio.Bitmap(WIDTH - 12, 14, 3)
bar_pal = displayio.Palette(3)
bar_pal[0] = WHITE
bar_pal[1] = BLACK
bar_pal[2] = RED
group.append(displayio.TileGrid(bar_bmp, pixel_shader=bar_pal, x=6, y=140))

display.root_group = group

count = 0
total = 0
last_len = 0
rssi = -120
snr = 0


def draw_bar():
    bar_bmp.fill(0)
    for i in range(WIDTH - 12):        # black frame
        bar_bmp[i, 0] = 1
        bar_bmp[i, 13] = 1
    for j in range(14):
        bar_bmp[0, j] = 1
        bar_bmp[WIDTH - 13, j] = 1
    frac = (rssi + 120) / 80.0         # -120..-40 dBm to empty..full
    frac = 0.0 if frac < 0 else (1.0 if frac > 1 else frac)
    for i in range(2, 2 + int(frac * (WIDTH - 16))):
        for j in range(2, 12):
            bar_bmp[i, j] = 2


def redraw():
    l_pkts.text = "Pkts %d" % count
    l_last.text = "Last %d B" % last_len
    l_rssi.text = "RSSI %d" % rssi
    l_snr.text = "SNR %d" % snr
    draw_bar()
    cyberaegg_epd.refresh(display)


redraw()
print("listening, dashboard redraws every few packets")
last = time.monotonic()
while True:
    data, err = radio.receive(timeout_ms=4000)
    if data:
        count += 1
        total += len(data)
        last_len = len(data)
        rssi = int(sx.getRSSI())
        snr = int(sx.getSNR())
        print("packet %d: %d bytes, RSSI %d dBm, SNR %d dB" % (count, last_len, rssi, snr))
    if time.monotonic() - last > 12:
        redraw()
        last = time.monotonic()
