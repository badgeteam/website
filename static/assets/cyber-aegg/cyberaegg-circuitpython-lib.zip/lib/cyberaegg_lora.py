"""LoRa on the CyberÆgg SX1262 radio.

Wraps the ehong-tl SX1262 driver with the badge's wiring and MeshCore-compatible
EU 869 MHz defaults. The badge uses a plain crystal (no TCXO) and a manual
antenna switch on LORA_RFSW that this class drives around send and receive.

    import cyberaegg_lora
    radio = cyberaegg_lora.LoRa()
    radio.send("hello")
    data, err = radio.receive(timeout_ms=5000)
"""
import board
import digitalio
from sx1262 import SX1262

# MeshCore private-network defaults for the EU 869 MHz band.
FREQUENCY_MHZ = 869.618
BANDWIDTH_KHZ = 62.5
SPREADING_FACTOR = 8
CODING_RATE = 5           # 4/5
SYNC_WORD = 0x12          # driver writes this to registers 0x0740/0x0741 as 0x1424
PREAMBLE_LENGTH = 8


class LoRa:
    def __init__(self, tx_power=22, current_limit=140.0,
                 freq=FREQUENCY_MHZ, bw=BANDWIDTH_KHZ, sf=SPREADING_FACTOR):
        # Antenna switch: high for receive, low for transmit. The driver also
        # sets DIO2 as an RF switch, matching the stock firmware.
        self._ant = digitalio.DigitalInOut(board.LORA_RFSW)
        self._ant.switch_to_output(value=True)

        self.radio = SX1262(
            spi_bus=0,
            clk=board.LORA_SCK,
            mosi=board.LORA_MOSI,
            miso=board.LORA_MISO,
            cs=board.LORA_CS,
            irq=board.LORA_DIO1,
            rst=board.LORA_RST,
            gpio=board.LORA_BUSY,
        )
        state = self.radio.begin(
            freq=freq,
            bw=bw,
            sf=sf,
            cr=CODING_RATE,
            syncWord=SYNC_WORD,
            power=tx_power,
            currentLimit=current_limit,
            preambleLength=PREAMBLE_LENGTH,
            tcxoVoltage=0.0,
            useRegulatorLDO=False,
            blocking=True,
        )
        if state != 0:
            raise RuntimeError("SX1262 begin failed with error %d" % state)

    def send(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8")
        self._ant.value = False
        try:
            return self.radio.send(data)
        finally:
            self._ant.value = True

    def receive(self, timeout_ms=0):
        self._ant.value = True
        return self.radio.recv(timeout_en=timeout_ms > 0, timeout_ms=timeout_ms)
