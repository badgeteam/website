"""Turnkey e-paper display for the BornHack 2026 CyberÆgg badge.

    import cyberaegg_epd
    display = cyberaegg_epd.get_display()   # a displayio.EPaperDisplay

152x152 tri-color (black/white/red) SSD1675B, driven with the panel's OTP
waveform. EPaperDisplay.refresh() is non-blocking. Poll `display.busy` to wait.
"""
import time
import board
import busio
import displayio
import fourwire
from epaperdisplay import EPaperDisplay

WIDTH = 152
HEIGHT = 152
WHITE = 0xFFFFFF
BLACK = 0x000000
RED = 0xFF0000

# One-time init. Ends with 0x22=0xF7 (load temp + LUT from OTP + display).
# Encoding: cmd, (len | 0x80 if a delay-ms byte follows), data...
_START = bytes((
    0x12, 0x80, 0x14,                # SW reset, wait 20 ms
    0x74, 0x01, 0x54,                # analog block control
    0x7E, 0x01, 0x3B,                # digital block control
    0x01, 0x03, 0x97, 0x00, 0x00,    # driver output control: 152 gates
    0x11, 0x01, 0x03,                # data entry: X inc, Y inc
    0x3C, 0x01, 0x05,                # border waveform
    0x18, 0x01, 0x80,                # internal temperature sensor
    0x22, 0x01, 0xF7,                # update ctrl 2: full update from OTP
))
_STOP = bytes((0x10, 0x01, 0x01))    # deep sleep


def get_display(spi=None):
    """Return the badge's EPaperDisplay, releasing any existing display first."""
    displayio.release_displays()
    if spi is None:
        spi = busio.SPI(clock=board.EPD_SCK, MOSI=board.EPD_MOSI)
    bus = fourwire.FourWire(
        spi,
        command=board.EPD_DC,
        chip_select=board.EPD_CS,
        reset=board.EPD_RST,
        baudrate=4_000_000,
    )
    return EPaperDisplay(
        bus, _START, _STOP,
        width=WIDTH, height=HEIGHT,
        ram_width=WIDTH, ram_height=HEIGHT,
        set_column_window_command=0x44,
        set_row_window_command=0x45,
        set_current_column_command=0x4E,
        set_current_row_command=0x4F,
        write_black_ram_command=0x24,     # 1=white, 0=black
        write_color_ram_command=0x26,     # 1=red
        highlight_color=RED,
        refresh_display_command=0x20,
        refresh_time=2,
        busy_pin=board.EPD_BUSY,
        busy_state=True,                  # BUSY high = busy
        seconds_per_frame=5,
        address_little_endian=True,
        start_up_time=0.01,
    )


def refresh(display):
    """Do one full refresh, respecting the panel's minimum interval, and block
    until it finishes. A tri-color full refresh takes on the order of 20 s."""
    while display.time_to_refresh > 0:
        time.sleep(display.time_to_refresh)
    display.refresh()
    while display.busy:
        time.sleep(0.05)


def clear(display=None):
    """Clear the panel to white with a single full refresh.

    Constructing an EPaperDisplay does not touch the glass, so a badge boots
    showing whatever was left there. Call this once on start for a clean panel.
    It is also the right thing to do before long storage or deep sleep, which
    is what actually prevents image retention. Returns the display so you can
    draw on it afterwards. Note a full refresh is slow (~20 s on this panel),
    so clear once and then only refresh again when the content changes.
    """
    if display is None:
        display = get_display()
    group = displayio.Group()
    bitmap = displayio.Bitmap(WIDTH, HEIGHT, 1)   # every pixel index 0
    palette = displayio.Palette(1)
    palette[0] = WHITE
    group.append(displayio.TileGrid(bitmap, pixel_shader=palette))
    display.root_group = group
    refresh(display)
    return display
